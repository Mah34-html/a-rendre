
public interface IService{
    public String affiche();
}